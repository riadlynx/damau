from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Profile)
admin.site.register(Fileup)
admin.site.register(Barrage)
admin.site.register(Instrument)
admin.site.register(Rapport)
admin.site.register(todo)