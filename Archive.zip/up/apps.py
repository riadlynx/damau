
from django.apps import AppConfig


class UpConfig(AppConfig):
    name = 'up'
